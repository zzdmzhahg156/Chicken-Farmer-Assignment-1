package builder.inventory;

public class TinyInventoryTest {

}